
fx_version 'adamant'

games { 'gta5' }
author 'General'


ui_page "client/html/ui.html"

files {
    "client/html/app.js",
    "client/html/style.css",
    "client/html/ui.html",
    --"client/html/delectcar.png",
}


client_scripts {
  "config.lua",
  "client/main.lua"
}

server_script {
  "config.lua",
  "server/server.lua"
}



author 'STIVENGAMER#3608'