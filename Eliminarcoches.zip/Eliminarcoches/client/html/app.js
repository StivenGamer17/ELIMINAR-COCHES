$(function() {
    window.addEventListener('message', function(event) {
        var item = event.data;
        var boxaction = $(".board");

        if (item.ShowMenu == true) {
            boxaction.fadeIn();
            $('#text1').html("<h4  style='margin-top: 3px;display: inline;'>en " + "<span class='timetextcolor'>" + item.textmin + " : " + item.textsec + "</span> segundos</h4>");
        } else {
            boxaction.fadeOut();
        }

    }, false);
});