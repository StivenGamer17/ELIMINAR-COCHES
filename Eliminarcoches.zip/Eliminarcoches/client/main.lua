ESX = exports["es_extended"]:getSharedObject()

local Keys = {
	["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57,
	["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177,
	["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
	["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
	["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
	["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70,
	["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
	["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118, ["Enter"] = 191
}



local pos = GetEntityCoords(NetworkGetEntityFromNetworkId(crateObj))

function DrawGenericTextThisFrame()
	SetTextFont(RegisterFontId('Kanit'))
	SetTextProportional(0)
	SetTextScale(0.0, 0.7)
	SetTextColour(255, 0, 0, 255)
	SetTextDropshadow(0, 0, 0, 0, 255)
	SetTextEdge(1, 0, 0, 0, 255)
	SetTextDropShadow()
	SetTextOutline()
	SetTextCentre(true)
end

function secondsToClock(seconds)
	local seconds, hours, mins, secs = tonumber(seconds), 0, 0, 0

	if seconds <= 0 then
		return 0, 0
	else
		local hours = string.format("%02.f", math.floor(seconds / 3600))
		local mins = string.format("%02.f", math.floor(seconds / 60 - (hours * 60)))
		local secs = string.format("%02.f", math.floor(seconds - hours * 3600 - mins * 60))

		return mins, secs
	end
end

function minToClock(seconds)
	local seconds, hours, mins, secs = tonumber(seconds), 0, 0, 0

	if seconds <= 0 then
		return 0, 0
	else
		local hours = string.format("%02.f", math.floor(seconds / 3600))
		local mins = string.format("%02.f", math.floor(seconds / 60 - (hours * 60)))
		local secs = string.format("%02.f", math.floor(seconds - hours * 3600 - mins * 60))

		return mins
	end
end

function secToClock(seconds)
	local seconds, hours, mins, secs = tonumber(seconds), 0, 0, 0

	if seconds <= 0 then
		return 0, 0
	else
		local hours = string.format("%02.f", math.floor(seconds / 3600))
		local mins = string.format("%02.f", math.floor(seconds / 60 - (hours * 60)))
		local secs = string.format("%02.f", math.floor(seconds - hours * 3600 - mins * 60))

		return secs
	end
end

local matchtime = 0

RegisterNetEvent("General:DelCar")
AddEventHandler("General:DelCar", function(_times)
	PlaySoundFrontend(-1, "NAV", "HUD_AMMO_SHOP_SOUNDSET", 1)
  local times = _times * 60
  print(times)
  local matchtime = ESX.Round(times)
  Citizen.CreateThread(function()
    while matchtime > 0 do
        Citizen.Wait(1000)
        if matchtime > 0 then
          matchtime = matchtime - 1 
        end
    end
  end)

  Citizen.CreateThread(function()
  while matchtime > 0 do
    Citizen.Wait(0)
     timetext = ('El sistema de borrar coche en. %s minuto %s segundo'):format(secondsToClock(matchtime))
	 mins = ('%s'):format(minToClock(matchtime))
	 sec = ('%s'):format(secToClock(matchtime))
	SendNUIMessage({
		ShowMenu = true,
		text1 = timetext,
		textmin = mins,
		textsec = sec,
	})
	if matchtime == 0 then
		for vehicle in EnumerateVehicles() do 
			if (not IsPedAPlayer(GetPedInVehicleSeat(vehicle, -1))) then  			
				SetVehicleHasBeenOwnedByPlayer(vehicle, false) 
				SetEntityAsMissionEntity(vehicle, false, false)  
				DeleteVehicle(vehicle) 
				if (DoesEntityExist(vehicle)) then 
					DeleteVehicle(vehicle) 	
				end
			end		
		end	
		SendNUIMessage({ShowMenu = false,})
	end
  end
end)

  local entityEnumerator = {
	__gc = function(enum)
		if enum.destructor and enum.handle then
			enum.destructor(enum.handle)
		end
		enum.destructor = nil
		enum.handle = nil
	end
}

	local function EnumerateEntities(initFunc, moveFunc, disposeFunc)
		return coroutine.wrap(function()
			local iter, id = initFunc()
			if not id or id == 0 then
				disposeFunc(iter)
				return
			end
		
			local enum = {handle = iter, destructor = disposeFunc}
			setmetatable(enum, entityEnumerator)
		
			local next = true
			repeat
				coroutine.yield(id)
				next, id = moveFunc(iter)
			until not next
		
			enum.destructor, enum.handle = nil, nil
			disposeFunc(iter)
		end)
	end

	function EnumerateVehicles() 
		return EnumerateEntities(FindFirstVehicle, FindNextVehicle, EndFindVehicle) 
	end
  
end)




