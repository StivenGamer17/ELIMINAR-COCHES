cfg = {}

cfg['command'] = 'grua'    -- /delallcar นาที
cfg['deltime'] = 3              -- default delete time
cfg['timer'] = {"08:00"}		-- time starting deletecar