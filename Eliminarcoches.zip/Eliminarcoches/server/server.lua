ESX = exports["es_extended"]:getSharedObject()

RegisterCommand(cfg['command'], function(source, args, user)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.getGroup() == 'admin' then
        local Text = args[1]
        local xTime = args[2]
    local time = args[1]
    if time == nil then
        TriggerClientEvent('General:DelCar', -1, cfg['deltime'])
    else
        TriggerClientEvent('General:DelCar', -1, time)
    end
end
end, true)


function delcar()
    SetTimeout(1000, function()
        local date_local = os.date('%H:%M:%S', os.time())        
        for i=1, #cfg['timer'], 1 do
            local start_time = cfg['timer'][i]..':00'
            if date_local == start_time then      
				TriggerClientEvent('General:DelCar', -1, cfg['deltime'])
            end
        end 
        delcar()   
	end)
end
delcar()